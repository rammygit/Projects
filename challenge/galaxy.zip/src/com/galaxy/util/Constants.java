package com.galaxy.util;

/**
 * 
 * @author ram
 *
 */
public class Constants {
	
	public static final String INPUT_SPLITTER = "\\sis\\s";
	
	public static final char EMPTY_CHAR = '\0';
	
	public static final String SPACE = "\\s";
	
	public static final char QUESTION_MARK = '?';
	
	
	
	
	

}
