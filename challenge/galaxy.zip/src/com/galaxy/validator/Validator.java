package com.galaxy.validator;


/**
 * 
 * @author ram
 *
 */
public interface Validator {
	
	
	boolean validate(String data);

}
